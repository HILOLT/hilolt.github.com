package com.tgb.lk.demo2.dao;

import java.io.File;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.tgb.lk.ahibernate.util.ADBHelper;
import com.tgb.lk.ahibernate.util.MyDBHelper;
import com.tgb.lk.demo.util.DBHelper;
import com.tgb.lk.demo2.model.Girl;

public class GirlDBHelper extends MyDBHelper{
	private static final String DBPATH=Environment.getExternalStorageDirectory().getAbsolutePath() + "/test/db/";
	private static final String DBNAME="girl.db";
	private static final int DB_VERSION=1;

	public GirlDBHelper(Context context) {
		super(context, DBPATH+DBNAME, null, DB_VERSION, new Class[]{Girl.class});
		Log.e("GirlDBHelper���ݿ⽨����", "���ݿ⽨����"+DBPATH+DBNAME);
		
	}
		static{
			File file = new File(DBPATH);
			if(!file.exists()){
				file.mkdirs();
			}
		}
}
