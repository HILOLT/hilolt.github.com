package com.tgb.lk.demo2.model;

import com.tgb.lk.ahibernate.annotation.Column;
import com.tgb.lk.ahibernate.annotation.Table;

@Table(name="T_GIRL")
public class Girl {
	@Column(name="girl_id")
	private int girl_id ;
	
	@Column(name="name")
	private String name;
	
	@Column(name="age")
	private int age;
	public int getGirl_id() {
		return girl_id;
	}
	public void setGirl_id(int girl_id) {
		this.girl_id = girl_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
