package com.tgb.lk.demo2;

import com.tgb.lk.demo2.dao.GirlDaoImpl;
import com.tgb.lk.demo2.model.Girl;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class Demo2Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		
	}
	public void inserEntity(View view){
		GirlDaoImpl girlDao = new GirlDaoImpl(Demo2Activity.this);
		Toast.makeText(this, "girl���ݿ���Ŀ"+girlDao.find().size(), 1).show();
		
	}
	/*public void inserEntity(View view){
		GirlDaoImpl girlDao = new GirlDaoImpl(Demo2Activity.this);
		Girl g = new Girl();
		g.setAge(22);
		g.setName("hh");
		g.setGirl_id(222);
		girlDao.insert(g, false);
		Log.e("���� flag=false","���� flag=false");
	}*/
	
	
	
	
	

}
