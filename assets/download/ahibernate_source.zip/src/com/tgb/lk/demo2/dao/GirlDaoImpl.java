package com.tgb.lk.demo2.dao;

import android.content.Context;
import com.tgb.lk.ahibernate.dao.impl.BaseDaoImpl;
import com.tgb.lk.demo2.model.Girl;

public class GirlDaoImpl extends BaseDaoImpl<Girl>{

	public GirlDaoImpl(Context context) {
		super(new GirlDBHelper(context));
	}
	
	
	
}
