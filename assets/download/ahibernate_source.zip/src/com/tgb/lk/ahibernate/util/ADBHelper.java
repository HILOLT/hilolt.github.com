package com.tgb.lk.ahibernate.util;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ADBHelper extends SQLiteOpenHelper {
	private Class<?> clazz;

	public ADBHelper(Context context, String databaseName, SQLiteDatabase.CursorFactory factory, int databaseVersion, Class<?> clazz) {
		super(context, databaseName, factory, databaseVersion);
		this.clazz = clazz;
	}

	public void onCreate(SQLiteDatabase db) {
		TableHelper.createTable(db, this.clazz);
		
	}

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		TableHelper.dropTable(db, this.clazz);
		onCreate(db);
	}
}